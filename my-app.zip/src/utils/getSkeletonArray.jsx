export default function getSkeletonArray() {
    const resArray = []
    for (let i = 0; i < 20; i += 1) resArray.push(i)
    return resArray
}
