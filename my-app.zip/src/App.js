import AppRoutes from "./Routes/Routes"
const App = () => {
  return (
    <>
      <AppRoutes/>
    </>
  )
}

export default App
